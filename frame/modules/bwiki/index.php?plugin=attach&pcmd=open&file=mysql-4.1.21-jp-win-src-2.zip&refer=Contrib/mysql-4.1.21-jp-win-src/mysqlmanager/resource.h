//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MySqlManager.rc
//
#define IDC_START_PB                    3
#define IDC_STOP_PB                     4
#define ID_SERVERS_PB                   7
#define IDD_ABOUTBOX                    100
#define IDM_QUERY_EXEC                  101
#define IDM_QUERY_DATABASES             102
#define IDM_REFRESH                     103
#define IDD_REGISTER_SERVER             114
#define IDR_MAINFRAME                   128
#define IDR_MYSQLMTYPE                  129
#define IDD_TOOL_SQL                    132
#define IDB_BITMAP1                     133
#define IDD_TOOL_SQL_QUERY              134
#define IDD_TOOL_SQL_RESULTS            135
#define IDD_TOOL_SQL_STATUS             136
#define IDC_TAB1                        1000
#define IDC_EDIT                        1001
#define IDC_QUERY_PB                    1002
#define IDC_FONT_PB                     1003
#define IDS_QUERY_EXEC                  1003
#define ID_SERVER_CB                    1003
#define ID_USER                         1004
#define IDC_SERVER_CB                   1004
#define IDC_DATABASES_PB                1005
#define ID_PASSWORD                     1005
#define ID_HOST_CB                      1006
#define IDC_TIMER_SECS                  1006
#define ID_PORT_CB                      1007
#define IDC_CLEAR                       1007
#define ID_GROUPS_PB                    1012
#define ID_REMOVE_PB                    1017
#define ID_DISPLAY_SERVER_STATUS_CK     1057
#define ID_USE_STANDARD_CK              1058
#define ID_USE_TRUSTED_CK               1059
#define IDM_SQL_TOOL_QUERY              32771
#define IDM_TOOLS_REGISTER_SERVER       32772
#define IDM_TOOLS_SERVER_PROPERTIES     32773
#define IDS_QUERY_DATABASES             57346
#define IDS_REFRESH                     57347

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
