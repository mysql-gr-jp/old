rm -f $MYSQL_TEST_DIR/var/master-data/test/rpl_misc_functions.outfile
