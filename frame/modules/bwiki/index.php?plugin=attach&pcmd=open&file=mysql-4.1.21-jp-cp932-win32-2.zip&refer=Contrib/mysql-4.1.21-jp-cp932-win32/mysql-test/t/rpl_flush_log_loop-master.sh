rm -f $MYSQL_TEST_DIR/var/slave-data/*-bin.*
rm -f $MYSQL_TEST_DIR/var/slave-data/master.info
rm -f $MYSQL_TEST_DIR/var/slave-data/*.index


