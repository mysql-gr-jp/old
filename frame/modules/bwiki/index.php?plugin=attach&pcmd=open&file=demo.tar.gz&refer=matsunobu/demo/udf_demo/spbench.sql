drop procedure spbench;
delimiter //
create procedure spbench(IN count INTEGER)
BEGIN
 DECLARE value,rand BIGINT DEFAULT 0;
 DECLARE done INTEGER DEFAULT 0;
 DECLARE i INTEGER DEFAULT 1;
 WHILE done != 1 DO
  set rand= i % 10000;
  select id into value from message where user_id=rand order by id desc limit 1;
  SET i = i + 1;
  IF i > count THEN
   SET done = 1;
  END IF;
 END WHILE;
END;
//
delimiter ;
