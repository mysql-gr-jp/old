#define MYSQL_SERVER 1
#include <mysql_priv.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

extern "C" my_bool bench_udf_init(UDF_INIT *initid, UDF_ARGS *args, char *message)
{
  if (args->arg_count > 1) 
  {
    strmov(message,"This function takes none or 1 argument");
    return 1;
  }
  if (args->arg_count > 0)
  {
    args->arg_type[0]= INT_RESULT;
  }
  if (!(initid->ptr= (char*) malloc(sizeof(longlong)))) {
    strmov(message,"Couldn't allocate memory");
    return 1;
  }
  bzero(initid->ptr,sizeof(longlong));
  initid->const_item= 0;
  srand((unsigned) time(NULL));
  return 0;
}


extern "C" void bench_udf_deinit(UDF_INIT *initid)
{
  if (initid->ptr)
    free(initid->ptr);
}


KEY *index_init(TABLE *table, const char *name, bool sorted) {
  for (uint keynr = 0; keynr < table->s->keys; keynr++) {
    if (strcmp(table->s->key_info[keynr].name, name) == 0) {
      if (table->file->ha_index_init(keynr, sorted) != 0) {
        return NULL;
      }
      return table->s->key_info + keynr;
    }
  }
  return NULL;
}  


Field *get_field(TABLE *table, const char *name) {
  Field **f;
  for (f = table->field; *f != NULL; f++) {
    if (strcmp((*f)->field_name, name) == 0) 
    {
      return *f;
    }
  }
  return NULL;
}


int do_process(uint count)
{
  DBUG_ENTER("do_process");
  THD *thd = current_thd;
  TABLE_LIST tables;
  TABLE *table;
  Field *message_id_fld;
  Field *message_user_id_fld;
  KEY *message_key;
  uint rows= 0;

  tables.init_one_table("test","message", TL_READ);
//  tables.init_one_table("test", 4, "message", 7, "message", TL_READ);
//  alloc_mdl_requests(&tables, thd->mem_root);

  if (simple_open_n_lock_tables(thd, &tables))
  {
    close_thread_tables(thd);
    DBUG_RETURN(-1);
  }
  table= tables.table;
  message_id_fld = get_field(table, "id");
  assert(message_id_fld != NULL);
  message_user_id_fld = get_field(table, "user_id");
  assert(message_user_id_fld != NULL);
  table->clear_column_bitmaps();
  bitmap_set_bit(table->read_set, message_id_fld->field_index);
  bitmap_set_bit(table->read_set, message_user_id_fld->field_index);

  message_key = index_init(table, "user_id", true);
  assert(message_key != NULL);

  uchar*  key_buff= (uchar*) thd->alloc(message_key->key_length);
  bzero(key_buff, message_key->key_length);

  int user_id=0;

  for(uint i= 0; i < count; i++)
  {
/* Equivalent query is 
     SELECT id FROM message WHERE user_id=? ORDER BY id DESC LIMIT 1; */
    int err;
    user_id= rand() % 10000 + 1;
    int null_offset= message_user_id_fld->null_bit; 
    int4store(key_buff + null_offset, user_id);
    err= table->file->index_read_last_map(table->record[0], key_buff, 1);

    if(err == HA_ERR_KEY_NOT_FOUND)
      fprintf(stderr, "not found user_id=%d\n", user_id);
    else if(err)
      fprintf(stderr, "unknown error %d,  user_id=%d\n", err, user_id);
    else
    {
      rows++;
//      fprintf(stderr, "base_user_id=%d, user_id=%lld, id=%lld\n", 
//              user_id, message_user_id_fld->val_int(), message_id_fld->val_int());
    }
  }

  table->file->ha_index_end();

  close_thread_tables(thd);
  DBUG_RETURN(rows);
}

extern "C" longlong bench_udf(UDF_INIT *initid __attribute__((unused)), UDF_ARGS *args,
                  char *is_null __attribute__((unused)),
                  char *error __attribute__((unused)))
{
  uint count= 100;
  if (args->arg_count > 0)
    count= *((longlong*) args->args[0]);
  int ret= do_process(count);
  return ret;
}



