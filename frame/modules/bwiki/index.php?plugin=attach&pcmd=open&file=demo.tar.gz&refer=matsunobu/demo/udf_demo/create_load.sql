CREATE TABLE `message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `body` varchar(255) default 'a', 
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`id`)
) engine=innodb;

# loading 2mil rows
drop procedure sp1;
delimiter //
create procedure sp1(IN count INTEGER)
BEGIN
 DECLARE done INTEGER DEFAULT 0;
 DECLARE i INTEGER DEFAULT 1;
 WHILE done != 1 DO
 insert into message values (i,rand()*10000,repeat(1,3));
  SET i = i + 1;
  IF i > count THEN
   SET done = 1;
  END IF;
 END WHILE;
END;
//
delimiter ;

call sp2(2000000);

