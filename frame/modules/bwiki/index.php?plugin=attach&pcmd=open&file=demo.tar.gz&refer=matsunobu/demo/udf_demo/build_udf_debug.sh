g++ -g -DSAFE_MUTEX -DSAFEMALLOC \
-Wall -fno-rtti -fno-exceptions -fPIC -shared \
-I/root/demo/mysql5400debugsrc/include \
-I/root/demo/mysql5400debugsrc/regex \
-I/root/demo/mysql5400debugsrc/sql \
-o bench_udf.so  bench_udf.cc
