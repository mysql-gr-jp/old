g++ -g \
-Wall -fno-rtti -fno-exceptions -fPIC -shared \
-I/root/demo/mysql5400src/include \
-I/root/demo/mysql5400src/regex \
-I/root/demo/mysql5400src/sql \
-o bench_udf.so  bench_udf.cc
