#define MYSQL_SERVER 1
#include <mysql_priv.h>
#include <mysql/plugin.h>
#include <stdlib.h>


ST_FIELD_INFO mem_info[]=
{
  {"NAME", 100, MYSQL_TYPE_STRING, 0, 0, "Variable", SKIP_OPEN_TABLE},
  {"SIZE(KB)", 20, MYSQL_TYPE_LONG, 0, 0, "Size(KB)", SKIP_OPEN_TABLE},
  {0, 0, MYSQL_TYPE_STRING, 0, 0, 0, SKIP_OPEN_TABLE}
};


int fill_meminfo(THD *thd, TABLE_LIST *tables, COND *cond)
{
  DBUG_ENTER("fill_meminfo");
  int status;
  CHARSET_INFO *scs= system_charset_info;
  TABLE *table= tables->table;
  FILE *meminfo;
  char line[500];
  char *name;
  char *value;
  char *e;
  unsigned long long val = 0;

  if ((meminfo = fopen("/proc/meminfo", "r")) != NULL)
  {
    while (fgets(line, sizeof line, meminfo) != NULL)
    {
      name= strtok(line, ": ");
      value= strtok(NULL,"kb");
      val= strtoull(value+1, &e, 10);
      table->field[0]->store(line,strlen(line), scs);
      table->field[1]->store(val, TRUE);
      status = schema_table_store_record(thd, table);
    }
  }
  fclose(meminfo);
  DBUG_RETURN(status);
}


static int mysql_is_meminfo_plugin_init(void *p)
{
  ST_SCHEMA_TABLE *schema= (ST_SCHEMA_TABLE *)p;

  schema->fields_info= mem_info;
  schema->fill_table= fill_meminfo;

  return 0;
}


static int mysql_is_meminfo_plugin_deinit(void *p)
{
  return 0;
}

struct st_mysql_information_schema mysql_meminfo_plugin=
{ MYSQL_INFORMATION_SCHEMA_INTERFACE_VERSION };

mysql_declare_plugin(mysql_meminfo)
{
  MYSQL_INFORMATION_SCHEMA_PLUGIN,                 /* type constant    */
  &mysql_meminfo_plugin,                          /* type descriptor  */
  "MEMINFO",                                   /* Name             */
  "Yoshinori Matsunobu (http://opendatabaselife.blogspot.com) ", /* Author           */
  "Linux Memory Statistics",                                   /* Description      */
  PLUGIN_LICENSE_GPL,                              /* License          */
  mysql_is_meminfo_plugin_init,                      /* Init function    */
  mysql_is_meminfo_plugin_deinit,                    /* Deinit function  */
  0x0010,                                          /* Version (1.0)    */
  NULL,                                            /* status variables */
  NULL,                                            /* system variables */
  NULL                                             /* config options   */
}
mysql_declare_plugin_end;

