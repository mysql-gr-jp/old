g++ -DMYSQL_DYNAMIC_PLUGIN \
-g -DSAFE_MUTEX -DSAFEMALLOC \
-Wall -fno-rtti -fno-exceptions -fPIC -shared \
-I/root/demo/mysql5400debugsrc/include \
-I/root/demo/mysql5400debugsrc/regex \
-I/root/demo/mysql5400debugsrc/sql \
-o meminfo.so meminfo.cc

